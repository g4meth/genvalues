ideologies = [
    {
        "name": "Marxism-Leninism ☭",
        "stats": {
            "grow": 80,
            "invo": 80,
            "mprg": 80,
            "cult": 80,
			"govt": 80,
			"seri": 80
        }
    },
	{
        "name": "Social Democracy 🌹",
        "stats": {
            "grow": 65,
            "invo": 65,
            "mprg": 65,
            "cult": 65,
			"govt": 65,
			"seri": 65
        }
    },
	{
        "name": "Centriᛋᛋm 卐",
        "stats": {
            "grow": 50,
            "invo": 50,
            "mprg": 50,
            "cult": 50,
			"govt": 50,
			"seri": 50,
        }
    },
	{
        "name": "Social Democracy 𓌏▌",
        "stats": {
            "grow": 35,
            "invo": 35,
            "mprg": 35,
            "cult": 35,
			"govt": 50,
			"seri": 35,
        }
    },
    {
        "name": "KillPeopleism 卐",
        "stats": {
            "grow": 20,
            "invo": 50,
            "mprg": 80,
            "cult": 20,
			"govt": 80,
			"seri": 50,
        }
    },
	{
        "name": "Anarcho-KillPeopleism 🏴卐",
        "stats": {
            "grow": 20,
            "invo": 50,
            "mprg": 20,
            "cult": 20,
			"govt": 20,
			"seri": 50,
        }
    },
	{
        "name": "Basic Human Empathy 🤗",
        "stats": {
            "grow": 100,
            "invo": 50,
            "mprg": 20,
            "cult": 100,
			"govt": 50,
			"seri": 50,
        }
    },
	{
        "name": "National Socialism 卐",
        "stats": {
            "grow": 15,
            "invo": 15,
            "mprg": 15,
            "cult": 15,
			"govt": 70,
			"seri": 15,
        }
    },
];